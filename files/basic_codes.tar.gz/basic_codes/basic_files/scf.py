from ase import io
from espresso import espresso
from ase.optimize import BFGS
mxene=io.read('scf.out')

scf='scf'
relax='relax'
mxene.set_pbc([True,True,True])

calc = espresso(pw= 700,
               dw=700*10,                    #density cutoff
               mode = 'scf',
               xc='BEEF-vdW',          #exchange-correlation functional
               kpts=(4, 4, 1),    #k-point sampling;
               nbands=-20, 
               nstep=200,         #100 extra bands besides the bands needed to hold
               #the valence  electrons
               sigma=0.1,
               convergence= {'energy':1e-6,
               'mixing':0.1,
               'nmix':10,
               'mix':4,
               'maxsteps':500,
               'diag':'david'},    #convergence parameters
               dipole={'status':True}, #diploe correction to account for periodicity in z
               spinpol=False,
               
	       output={'avoidio':False,
                    'removewf':True,
                    'wf_collect':False},
	       onlycreatepwinp = 'scf.in',
	       outdir='calcdir')  #output directory for Quantum Espresso

mxene.set_calculator(calc)
calc.initialize(mxene)
