from sklearn.datasets import make_regression
from sklearn.linear_model import Lasso
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

df = pd.read_csv("pathway/to/your/csvfile")
y = df['E_ads (eV)'].values
x_df = df.drop(columns=['Metadata', 'E_ads (eV)'])
X = x_df.values
header = x_df.columns

# 1. Generate sample data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2
)

# 2. Build a pipeline to scale features and fit Lasso
model = make_pipeline(StandardScaler(), Lasso(alpha=0.01))
model.fit(X_train, y_train)

# 3. Evaluate and inspect coefficients
print(f"R² Score: {model.score(X_test, y_test):.3f}")

params = model.named_steps["lasso"].coef_
intercept = model.named_steps["lasso"].intercept_

mask = np.isclose(params, 0, atol=1e-5) == False
print("Number of Non-Zero Parameters:", len(params[mask]))
print("Non-Zero Parameters:", header[mask])

y_pred = model.predict(X_test)
y_pred_train = model.predict(X_train)



# 4. Test Data - Plot actual vs predicted values 
plt.plot([y_test.min()-0.5, y_test.max()+0.5], [y_test.min()-0.5, y_test.max()+0.5], 'k', lw=2)
plt.scatter(y_test, y_pred)
plt.xlim(y_test.min()-0.5, y_test.max()+0.5)
plt.ylim(y_test.min()-0.5, y_test.max()+0.5)
plt.xlabel("Actual Values")
plt.ylabel("Predicted Values")
plt.title("Lasso Regression Performance")
plt.savefig("lasso_performance_test.png", dpi=300)

plt.clf()  # Clear the figure for the next plot

# 4. Train Data - Plot actual vs predicted values 
plt.plot([y_train.min()-0.5, y_train.max()+0.5], [y_train.min()-0.5, y_train.max()+0.5], 'k', lw=2)
plt.scatter(y_train, y_pred_train)
plt.xlim(y_train.min()-0.5, y_train.max()+0.5)
plt.ylim(y_train.min()-0.5, y_train.max()+0.5)
plt.xlabel("Actual Values")
plt.ylabel("Predicted Values")
plt.title("Lasso Regression Performance")
plt.savefig("lasso_performance_train.png", dpi=300)