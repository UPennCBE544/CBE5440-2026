"""Apply a trained single-task SISSO++ model to a descriptor CSV."""

import argparse
import csv
import math
from pathlib import Path
import re

from simpleeval import simple_eval

TARGET = "E_ads (eV)"
PREDICTION = "SISSO predicted E_ads (eV)"
FUNCTIONS = {
    name: getattr(math, name)
    for name in ("sqrt", "exp", "log", "sin", "cos", "tan")
}
FUNCTIONS.update(abs=abs, cbrt=lambda x: math.copysign(abs(x) ** (1 / 3), x))


def read_model(path):
    coefficients = None
    in_coefficients = False
    expressions = []
    features = set()

    with path.open(encoding="utf-8") as model:
        for line in model:
            if line.startswith("# Sample ID"):
                break
            if line.startswith("# Coefficients"):
                in_coefficients = True
            elif line.startswith(("# Feature Rung", "# Number of Samples")):
                in_coefficients = False
            if in_coefficients and re.match(r"^#\s*all\s*,", line):
                coefficients = [float(value) for value in line.split(",")[1:] if value.strip()]
            fields = line.removeprefix("#").split(";")
            if fields[0].strip().isdigit() and len(fields) >= 6:
                expressions.append(fields[4].strip())
                features.update(name.strip() for name in fields[-1].split(",") if name.strip())

    if not expressions or coefficients is None or len(coefficients) != len(expressions) + 1:
        raise ValueError("Expected a single-task SISSO++ model with a '# all' coefficient row.")

    return coefficients, expressions, sorted(features)


def predict(model_path, data_path):
    coefficients, expressions, features = read_model(model_path)
    aliases = {name: f"feature_{i}" for i, name in enumerate(features)}
    if aliases:
        names = "|".join(map(re.escape, sorted(aliases, key=len, reverse=True)))
        pattern = re.compile(r"(?<!\w)(?:" + names + r")(?!\w)")
        expressions = [pattern.sub(lambda match: aliases[match[0]], expr) for expr in expressions]
    expressions = [expr.replace("^", "**") for expr in expressions]

    with data_path.open(encoding="utf-8-sig", newline="") as data:
        reader = csv.DictReader(data)
        headers = reader.fieldnames or []
        if not headers:
            raise ValueError("The descriptor CSV is empty.")
        if len(headers) != len(set(headers)) or PREDICTION in headers:
            raise ValueError("The CSV has duplicate headers or already contains a prediction column.")

        columns = {}
        for name in features:
            matches = [header for header in headers if re.sub(r"\s+\([^()]*\)$", "", header) == name]
            if len(matches) != 1:
                raise ValueError(f"Expected exactly one CSV column for feature {name!r}; found {matches}.")
            columns[aliases[name]] = matches[0]

        rows = []
        comparisons = []
        for row in reader:
            try:
                if None in row or None in row.values():
                    raise ValueError("Column count differs from the header.")
                values = {alias: float(row[column]) for alias, column in columns.items()}
                if not all(map(math.isfinite, values.values())):
                    raise ValueError("A required feature is not finite.")
                estimate = coefficients[-1] + math.fsum(
                    coefficient * simple_eval(expr, names=values, functions=FUNCTIONS)
                    for coefficient, expr in zip(coefficients[:-1], expressions)
                )
                if not math.isfinite(estimate):
                    raise ValueError("Prediction is not finite.")
                target = row.get(TARGET, "").strip()
                if target:
                    observed = float(target)
                    if math.isfinite(observed):
                        comparisons.append((observed, estimate))
            except Exception as error:
                raise ValueError(f"CSV line {reader.line_num}: {error}") from error

            row[PREDICTION] = estimate
            rows.append(row)

    if not rows:
        raise ValueError("The descriptor CSV has no data rows.")
    return headers, rows, comparisons


def save_plot(path, rows, comparisons):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(5.2, 4.8), layout="constrained")
    if comparisons:
        observed, predicted = zip(*comparisons)
        rmse = math.sqrt(
            math.fsum((true - pred) ** 2 for true, pred in comparisons) / len(comparisons)
        )
        low = min(*observed, *predicted)
        high = max(*observed, *predicted)
        pad = 0.05 * (high - low) if high > low else 0.1
        limits = (low - pad, high + pad)
        ax.plot(limits, limits, "--", color="0.4", linewidth=1)
        ax.scatter(observed, predicted, s=20, alpha=0.65)
        ax.set(xlim=limits, ylim=limits, aspect="equal")
        ax.set_xlabel("DFT adsorption energy (eV)")
        ax.set_ylabel("SISSO-predicted adsorption energy (eV)")
        ax.set_title(f"RMSE = {rmse:.3g} eV (n = {len(comparisons)})")
        print(f"RMSE: {rmse:.6g} eV ({len(comparisons)} rows with finite DFT energies)")
    else:
        ax.hist([row[PREDICTION] for row in rows], bins="auto", edgecolor="white")
        ax.set_xlabel("SISSO-predicted adsorption energy (eV)")
        ax.set_ylabel("Number of samples")

    with path.open("xb") as output:
        fig.savefig(output, format="png", dpi=300)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path, help="Trained SISSO++ model .dat file")
    parser.add_argument("dataset", type=Path, help="New descriptor CSV")
    parser.add_argument("-o", "--output", type=Path, default=Path("predictions.csv"))
    args = parser.parse_args()
    plot_path = args.output.with_name(f"{args.output.stem}_plot.png")

    try:
        headers, rows, comparisons = predict(args.model, args.dataset)
        with args.output.open("x", encoding="utf-8", newline="") as output:
            writer = csv.DictWriter(output, fieldnames=[*headers, PREDICTION])
            writer.writeheader()
            writer.writerows(rows)
        print(f"Saved {len(rows)} predictions to {args.output}")
        save_plot(plot_path, rows, comparisons)
    except (OSError, ValueError, ImportError) as error:
        parser.exit(1, f"Error: {error}\n")

    print(f"Saved plot to {plot_path}")


if __name__ == "__main__":
    main()