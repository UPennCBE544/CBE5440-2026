import ase
from domain_decomp import get_molecules, get_6_nearest_neighbors
import elec_module as em
import geom_module as gm
import ads_module as am
from ase import io
from ase.dft import get_distribution_moment
from ase.data import atomic_masses, atomic_numbers, chemical_symbols, covalent_radii
import numpy as np
import pandas as pd
import os
import re
from sys import argv

data_file = argv[1]
savefile = 'SISSO_data.csv'

ads_traj_head = 'file_path'
clean_traj_head = 'path_to_base'
ads_ref_head = 'ads_ref'
dos_path_head = 'dos_path'
pdos_path_head = 'pdos_path'
acf_path_head = 'bader_path'
E_ads_head = 'E_ads'

# Dictionaries, lists, etc
tm_list = list(range(21, 31)) + list(range(39, 49)) + list(range(72, 81)) + list(range(104, 113))

def ads_above(atoms, ads_indices):
    # Returns true if most of the adsorbate is above the slab, false otherwise
    pos = atoms.get_positions()
    mpos = np.array([a.position for a in atoms if a.number in tm_list])
    apos = pos[list(ads_indices)]

    max_metal_z = np.max(mpos[:, 2])
    ads_above = np.sum(apos[:, 2] > max_metal_z)

    return ads_above > (0.5 * len(apos))

def adsorbed_atom_position(atoms, ads_indices, C = False):
    pos = atoms.get_positions()
    syms = atoms.get_chemical_symbols()

    if C:
        temp_pos = np.array([pos[a] for a in ads_indices if syms[a] != 'H'])
    else:
        temp_pos = np.array([pos[a] for a in ads_indices])

    if ads_above(atoms, ads_indices):
        ads_pos = temp_pos[np.argmin(temp_pos[:,2])]
    else:
        ads_pos = temp_pos[np.argmax(temp_pos[:,2])]

    ads_pos_index = np.where((pos == ads_pos).all(axis=1))[0][0]

    return ads_pos, ads_pos_index

def get_indices(adsorbed_traj, clean_traj, ref_traj, site, term=''):
    surf_indices = []
    ads_indices = []
    exit_flag = 0

    ###################################
    #------READ THE TRAJECTORIES------#
    ###################################
    try:
        init_traj = io.read(adsorbed_traj, 0) # Initial frame of the ADSORBED MXene
    except:
        return 0, 0, 1
    final_traj = io.read(adsorbed_traj) # Relaxed ADSORBED MXene

    try:
        clean_opt = io.read(clean_traj) # Reference trajectory (optimized NON-ADSORBED MXene onto which adsorbate was added). The surface atom positions must match those of the adsorbed trajectory.
    except:
        return 0, 0, 2
    try:
        ref = io.read(ref_traj) # Relaxed ADSORBATE in vacuum
    except:
        return 0, 0, 3

    # Get necessary information from trajectories
    syms = init_traj.get_chemical_symbols()
    init_nums = init_traj.get_atomic_numbers()
    init_positions = init_traj.get_positions(wrap = True)
    init_tm_pos = np.array([a.position for a in init_traj if a.number in tm_list])
    init_tm_ref_index = np.argmin(np.array([np.linalg.norm(p) for p in init_tm_pos]))
    ads_temp = init_positions - init_tm_pos[init_tm_ref_index]  # Reference all positions to transition metal closest to origin

    clean_nums = clean_opt.get_atomic_numbers()
    clean_positions = clean_opt.get_positions(wrap = True)
    clean_tm_pos = np.array([a.position for a in clean_opt if a.number in tm_list])
    clean_tm_ref_index = np.argmin(np.array([np.linalg.norm(p) for p in clean_tm_pos]))
    clean_temp = clean_positions - clean_tm_pos[clean_tm_ref_index]  # Reference all positions to transition metal closest to origin

    ###################################
    #--------FIND THE INDICES---------#
    ###################################

    # Surface atoms in adsorbed trajectory
    surf_indices = [
        i for i, pos in enumerate(ads_temp)
        if np.any(np.all(np.isclose(pos, clean_temp, atol=0.6), axis=1))
        ]

    # Surface atoms in clean trajectory
    clean_surf_indices = [i for i, pos in enumerate(clean_temp)
        if np.any(np.all(np.isclose(pos, ads_temp[surf_indices], atol=0.6), axis=1))
        ]
    
    # Atoms that exist in clean trajectory and not adsorbed trajectory
    extra_indices = [i for i in range(len(clean_opt)) if i not in clean_surf_indices]
    # print('Additional atoms found in clean:', extra_indices)

    # Adsorbate atoms in adsorbed trajectory. Used to find site indices in clean trajectory
    ads_indices = [i for i in range(len(init_traj)) if i not in surf_indices]

    molecules = get_molecules(init_traj, ads_indices)
    ads_pos=[]
    ads_index = []

    for mol in molecules:
        if any([syms[m] == 'C' for m in mol]):
            temp1, temp2 = adsorbed_atom_position(init_traj, mol, C = True)
        else:
            temp1, temp2 = adsorbed_atom_position(init_traj, mol)
        ads_pos.append(temp1)
        ads_index.append(temp2)

    neighbors = []
    neigh_metals = []

    clean_site_indices = set()

    for p in ads_pos:
        ref_position = p - init_tm_pos[init_tm_ref_index] + clean_tm_pos[clean_tm_ref_index]
        neigh = get_6_nearest_neighbors(clean_opt, ref_position, cutoff = 10, ignore = extra_indices)
        neighbors.append(neigh)

    try:
        if site != 'top':
            for i, n in enumerate(neighbors):
                clean_site_indices.update(n[0:3])
        else:
            for i, n in enumerate(neighbors):
                clean_site_indices.add(n[0])
    except:
        print(f'Neighbor list error. Neighbors: {neighbors}, metal indices: {neigh_metals}\n')
        return 0, 0 ,4

    clean_M_indices = [i for i, n in enumerate(clean_nums) if n in tm_list] # Get indices of transition metals
    clean_CN_indices = [i for i, p in enumerate(clean_positions) if (p[2] < np.max(clean_tm_pos[:,2])) and (p[2] > np.min(clean_tm_pos[:,2])) and clean_nums[i] in [6, 7]]
    clean_Tx_indices = [i for i in clean_surf_indices if (i not in clean_M_indices) and (i not in clean_CN_indices) and i not in extra_indices]

    all_indices = [clean_M_indices, clean_CN_indices, clean_Tx_indices, clean_surf_indices, list(clean_site_indices)]
    
    all_atomic_numbers = []
    for ai in all_indices:
        all_atomic_numbers.append(list(clean_nums[ai]))

    # The indices list is in order of M, CN, Tx, Surf, and Site. Nums are the atomic numbers of the elements in all_indices
    return all_indices, all_atomic_numbers, exit_flag

# The indices list is in order of M, CN, Tx, Surf, and Site. Nums are the atomic numbers of the elements of the list
labels = ['M','CN','Tx','surf','site']

elec_feat_labels = ['s_center (eV)', 's_var (eV^2)', 's_skew (eV^3)', 's_kurt (eV^4)', 's_fill (eV)',  
            'p_center (eV)', 'p_var (eV^2)', 'p_skew (eV^3)', 'p_kurt (eV^4)', 'p_fill (eV)',  
            'sp_center (eV)', 'sp_var (eV^2)', 'sp_skew (eV^3)', 'sp_kurt (eV^4)', 'sp_fill (eV)', 
            'd_center (eV)', 'd_var (eV^2)', 'd_skew (eV^3)', 'd_kurt (eV^4)', 'd_fill (eV)', 
            'total_center (eV)', 'total_var (eV^2)', 'total_skew (eV^3)', 'total_kurt (eV^4)', 'total_fill (eV)',
            'tDOS_at_EF', 'charge_avg', 'charge_sum', 'charge_std', 'charge_max', 'charge_min']

geom_projected_feat_labels = ['bond_length_avg (AA)', 'bond_length_std (AA)', 'bond_length_sum (AA)', 'bond_length_min (AA)', 'bond_length_max (AA)']

geom_total_feat_labels = ['lattice_param_a (AA)','lattice_param_b (AA)','lattice_param_c (AA)','lattice_param_alpha (deg)','lattice_param_beta (deg)','lattice_param_gamma (deg)']

ads_formula_labels = am.labels

# ALL FEATURES

with open(savefile,'w') as f:
    # First column of the file is the Metadata
    head = ['Metadata']

    # Add columns for all sublabels of electronic labels
    for label in labels:
        for f_label in elec_feat_labels:
            tempstr = label + '_' + f_label
            head.append(tempstr)

    # Add columns for all sublabels of geomectric labels
    for i in range(len(labels[0:3])):
        for j in range(i, len(labels[0:3])):
            for f_label in geom_projected_feat_labels:
                tempstr = labels[i] + '_' + labels[j] + '_' + f_label
                head.append(tempstr)

    # Add columns for non-atomic geometric labels
    for f_label in geom_total_feat_labels:
        head.append(f_label)

    for f_label in ads_formula_labels:
        head.append(f_label)

    head.append('E_ads (eV)')
    f.write(','.join(head) + '\n')

    data_points = pd.read_csv(data_file)
    for _, row in data_points.iterrows():
        metadata = str(row['structure']) + '_' + str(row['termination']) + '_' + str(row['coverage'])
        print(metadata)

        ads_traj = row[ads_traj_head]
        clean_traj = row[clean_traj_head]
        ads_ref = row[ads_ref_head]
        dos_path = row[dos_path_head] + '/dos.dos'
        pdos_path = row[pdos_path_head]
        acf_path = row[acf_path_head] + '/ACF.dat'
        E_ads = row[E_ads_head]

        try:
            e_f, _, _, _ = em.dos_loader(dos_path)
        except:
            print(f'Issue reading {dos_path}\n')
            continue

        indices, nums, exit_flag = get_indices(ads_traj, clean_traj, ads_ref, 'top')
        if exit_flag == 1:
            print(f'Issue reading {ads_traj}\n')
            continue
        elif exit_flag == 2:
            print(f'Issue reading {clean_traj} or opt.traj\n')
            continue
        elif exit_flag == 3:
            print(f'Issue reading {ads_ref}\n')
            continue
        elif exit_flag == 4:
            continue

        print(indices[-1])

        line = [metadata]

        continue_flag = False
        for i, ind in enumerate(indices):
            try:
                feats = em.get_pdos_properties(pdos_path, ind, e_f)
            except:
                print(f'Issue reading {pdos_path}\n')
                continue_flag = True
                break

            try:
                ftemp = em.get_bader_properties(acf_path, ind)
            except:
                print(f'Issue reading {acf_path}\n')
                ftemp = []
                continue_flag = True
                break
                
            feats.extend(ftemp)
            for feat in feats:
                line.append(str(feat))
        
        if continue_flag:
            continue

        for i in range(len(indices[0:3])):
            for j in range(i, len(indices[0:3])):
                feats = gm.get_bond_lengths(clean_traj, indices[i], indices[j])
                for feat in feats:
                    line.append(str(feat))

        feats = gm.get_lattice_parameters(clean_traj)
        for feat in feats:
            line.append(str(feat))

        feats = am.get_adsorbate_composition(ads_ref)
        for feat in feats:
            line.append(str(feat))

        line.append(str(E_ads))
        f.write(','.join(line) + '\n')
        f.flush()
        print('Done\n')