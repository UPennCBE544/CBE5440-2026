import numpy as np
import ase
from ase.data import covalent_radii

tm_list = list(range(21, 31)) + list(range(39, 49)) + list(range(72, 81)) + list(range(104, 113))

class DomainDecomp:
    def __init__(self, box, cutoff):
        self.box = box
        self.cells = {} #cells that represent decomposed box
        self.atom_numbers = []
        self.cell_size = cutoff
        self.n_cells = np.ceil(np.linalg.norm(self.box, axis=1)/self.cell_size).astype(int)

    def get_cell_index(self, pos):
        fractional_coords = np.linalg.solve(self.box.T, pos)
        fractional_coords = fractional_coords % 1  # Wrap coordinates to be within [0, 1)
        return tuple((fractional_coords // (1/self.n_cells)).astype(int))

    def add_atom(self, atom_index, pos, atom_number):
        cell_index = self.get_cell_index(pos)
        if cell_index not in self.cells:
            self.cells[cell_index] = []
        self.cells[cell_index].append((atom_index, pos))
        self.atom_numbers.append(atom_number)

    def calculate_distance(self, pos1, pos2):
        delta = pos1 - pos2
        frac = np.linalg.solve(self.box.T, delta)
        frac -= np.round(frac)
        delta = np.dot(frac, self.box)
        return np.linalg.norm(delta)
    
    def get_cutoff(self, index1, index2):
        r1 = covalent_radii[self.atom_numbers[index1]]
        r2 = covalent_radii[self.atom_numbers[index2]]
        return 1.15*(r1 + r2)

    def find_neighbors(self, atom_index, pos):
        neighbors = []
        cell_index = self.get_cell_index(pos)
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                for dz in [-1, 0, 1]:
                    neighbor_cell_index = tuple((np.array(cell_index) + np.array([dx, dy, dz])) % self.n_cells)
                    if neighbor_cell_index in self.cells:
                        for neighbor_atom_index, neighbor_position in self.cells[neighbor_cell_index]:
                            if neighbor_atom_index != atom_index and (self.atom_numbers[atom_index] not in tm_list) and (self.atom_numbers[neighbor_atom_index] not in tm_list):
                                distance = self.calculate_distance(pos, neighbor_position)
                                cutoff = self.get_cutoff(atom_index, neighbor_atom_index)
                                if distance < cutoff:
                                    neighbors.append(neighbor_atom_index)

        return neighbors
    
    def find_neighbors_nonbonding(self, pos, ignore = []):
        neighbors = []
        distances = []
        cell_index = self.get_cell_index(pos)
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                for dz in [-1, 0, 1]:
                    neighbor_cell_index = tuple((np.array(cell_index) + np.array([dx, dy, dz])) % self.n_cells)
                    if neighbor_cell_index in self.cells:
                        for neighbor_atom_index, neighbor_position in self.cells[neighbor_cell_index]:
                            distance = self.calculate_distance(pos, neighbor_position)
                            if distance < self.cell_size/2 and (neighbor_atom_index not in neighbors) and (neighbor_atom_index not in ignore):
                                neighbors.append(neighbor_atom_index)
                                distances.append(distance)

        return neighbors, distances

def get_molecules(atoms, indices):
    # argument atoms is the ASE Atoms object with all atom information
    # argument indices is the subset of indices from which molecules will be identified

    box = atoms.get_cell()
    pos = atoms.get_positions()

    n = atoms.get_atomic_numbers()
    anums = set(n[i] for i in indices)
    radii = np.array([covalent_radii[a] for a in anums])
    cell_size = 2.0 * np.max(radii) * 1.15

    domains = DomainDecomp(box, cell_size)

    for i in range(len(atoms)):
        domains.add_atom(i, pos[i], n[i])


    def find_molecule(atom_index, visited):
        stack = [atom_index]
        molecule = []

        while stack:
            current_atom = stack.pop()
            if current_atom not in visited and current_atom in indices:
                visited.add(current_atom)
                molecule.append(current_atom)
                neighbors = domains.find_neighbors(current_atom, pos[current_atom])
                for neighbor in neighbors:
                    if neighbor not in visited:
                        stack.append(neighbor)

        return molecule
    
    molecules = []
    visited = set()
    for i in indices:
        if i not in visited:
            molecule = find_molecule(i, visited)
            molecules.append(tuple(molecule))

    return molecules

def get_6_nearest_neighbors(atoms, ref_position, cutoff, ignore = []):
    cell_size = cutoff
    box = atoms.get_cell()
    pos = atoms.get_positions()
    n = atoms.get_atomic_numbers()

    domains = DomainDecomp(box, cell_size)

    for i in range(len(atoms)):
        domains.add_atom(i, pos[i], n[i])

    neighbors, distances = domains.find_neighbors_nonbonding(ref_position, ignore = ignore)

    if len(distances) >= 6:
        near6 = np.argsort(np.abs(distances))[:6]
    else:
        near6 = np.argsort(np.abs(distances))

    return [neighbors[i] for i in near6]