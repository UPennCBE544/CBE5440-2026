import ase
from ase import io
from ase.dft import get_distribution_moment
from ase.data import atomic_masses, atomic_numbers, chemical_symbols, covalent_radii
import numpy as np
import os

def dos_loader(dos_path):
    energy = []
    dos = []
    idos = []
    with open(dos_path, 'r') as f:
        lines = f.readlines()
        for line in lines:
            if line.startswith('#'):
                parts = line.split()
                e_f = float(parts[-2])
                continue
            parts = line.split()
            energy.append(float(parts[0]))
            dos.append(float(parts[1]))
            idos.append(float(parts[2]))

    return e_f, np.array(energy), np.array(dos), np.array(idos)


def pdos_loader(pdos_path):
    energy = []
    ldos = []
    pdos = []
    with open(pdos_path, 'r') as f:
        lines = f.readlines()
        for line in lines:
            if line.startswith('#'):
                continue
            parts = line.split()
            energy.append(float(parts[0]))
            ldos.append(float(parts[1]))
            pdos.append([float(x) for x in parts[2:]])

    return np.array(energy), np.array(ldos), np.array(pdos)

def get_moments_and_fill(energies, dos):

    mask = np.logical_and(energies >= -20, energies <=25)
    fill_mask = np.where(energies <= 0)

    fill_dos = dos[fill_mask]
    DOS_at_EF = fill_dos[-1]

    fill = get_distribution_moment(energies[fill_mask], fill_dos)
    center = get_distribution_moment(energies[mask], dos[mask], order=1)
    var = get_distribution_moment(energies[mask], dos[mask], order=2)
    skew = get_distribution_moment(energies[mask], dos[mask], order=3)
    kurt = get_distribution_moment(energies[mask], dos[mask], order=4)

    if np.isnan(fill):
        fill = 0
    if np.isnan(center):
        center = 0
    if np.isnan(var):
        var = 0
    if np.isnan(skew):
        skew = 0
    if np.isnan(kurt):
        kurt = 0

    return center, var, skew, kurt, fill, DOS_at_EF

def get_pdos_properties(pdos_path, indices, e_f):
    files = [f for f in os.listdir(pdos_path) if f.startswith('pdos.dos')]
    for i, f in enumerate(files):
        if i == 0:
            energies, _, _ = pdos_loader(os.path.join(pdos_path, f))
            energies -= e_f
            tot_s = np.zeros_like(energies)
            tot_p = np.zeros_like(energies)
            tot_sp = np.zeros_like(energies)
            tot_d = np.zeros_like(energies)
            
        if '_tot' not in f:
            index = int(f.split('#')[1].split('(')[0])-1
            orbital = f.split('(')[-1].split(')')[0]
            if index in indices:
                _, _, pdos = pdos_loader(os.path.join(pdos_path, f))
                temp = np.sum(pdos, axis=1)
                if orbital == 's':
                    tot_s += temp
                    tot_sp += temp
                elif orbital =='p':
                    tot_p += temp
                    tot_sp += temp
                elif orbital == 'd':
                    tot_d += temp

    sum_pdos = tot_s + tot_p + tot_d
    
    e_s, s_var, s_skew, s_kurt, s_fill, sDOS_at_EF = get_moments_and_fill(energies,tot_s)

    if sum(tot_p) != 0:
        e_p, p_var, p_skew, p_kurt, p_fill, pDOS_at_EF = get_moments_and_fill(energies, tot_p)
        e_sp, sp_var, sp_skew, sp_kurt, sp_fill, spDOS_at_EF = get_moments_and_fill(energies, tot_sp)
    else:
        e_p, p_var, p_skew, p_kurt, p_fill, pDOS_at_EF = 0,0,0,0,0,0
        e_sp, sp_var, sp_skew, sp_kurt, sp_fill, spDOS_at_EF = 0,0,0,0,0,0

    if sum(tot_d) != 0:
        e_d, d_var, d_skew, d_kurt, d_fill, dDOS_at_EF = get_moments_and_fill(energies, tot_d)
    else:
        e_d, d_var, d_skew, d_kurt, d_fill, dDOS_at_EF = 0,0,0,0,0,0

    total_center, total_var, total_skew, total_kurt, total_fill, tDOS_at_EF = get_moments_and_fill(energies, sum_pdos)

    return [e_s, s_var, s_skew, s_kurt, s_fill,  
            e_p, p_var, p_skew, p_kurt, p_fill,  
            e_sp, sp_var, sp_skew, sp_kurt, sp_fill, 
            e_d, d_var, d_skew, d_kurt, d_fill, 
            total_center, total_var, total_skew, total_kurt, total_fill,
            tDOS_at_EF]

def get_bader_properties(acf_file, indices):
    charges = []
    with open(acf_file, 'r') as f:
        lines = f.readlines()
        for line in lines:
            parts = line.split()
            if parts[0].isdigit():
                if int(parts[0]) in indices:
                    charges.append(float(parts[4]))
    charges = np.array(charges)
    if charges.size > 0:
        return [np.mean(charges),
                np.sum(charges),
                np.std(charges),
                np.max(charges),
                np.min(charges)]
    else:
        return [0]*5