import ase
from ase import io, Atoms
from ase.data import chemical_symbols

labels = []

for el in chemical_symbols[1:]:
    labels.append('ads_num_'+el)

def get_adsorbate_composition(file):
    atoms = io.read(file)
    lis = atoms.get_chemical_symbols()
    temp = [int(0)]*(len(chemical_symbols)-1)
    for el in lis:
        temp[chemical_symbols.index(el)-1] += 1
    return temp