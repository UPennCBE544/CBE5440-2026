import ase
from ase import io
from ase.data import atomic_masses, atomic_numbers, chemical_symbols, covalent_radii
import numpy as np
import os