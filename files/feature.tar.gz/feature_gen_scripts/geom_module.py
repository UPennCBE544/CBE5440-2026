import numpy as np
import ase
from ase import Atoms, io
from ase.geometry.analysis import Analysis

def get_bond_lengths(image_path, indices1, indices2):
    image = io.read(image_path)
    An = Analysis(image)
    bonds = An.all_bonds
    lengths = []
    counted = []
    for i, sublist in enumerate(bonds[0]):
        for j in sublist:
            if (i in indices1) and (j in indices2) and tuple([i,j]) not in counted and tuple([j,i]) not in counted:
                temp = tuple([i,j])
                counted.append(temp)
                length = An.get_bond_value(0,temp)
                lengths.append(length)
                
    del image
    lengths = np.array(lengths)

    if lengths.size == 0:
        return np.zeros(5)
    else:
        return [np.mean(lengths),
                np.std(lengths),
                np.sum(lengths),
                np.min(lengths),
                np.max(lengths)]

def get_lattice_parameters(image_path):
    image = io.read(image_path)
    arr = image.cell.cellpar()
    del image
    return arr